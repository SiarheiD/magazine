
	// $("main").turn({
	// 	width: 750,
	// 	height: 667,
	// 	autoCenter: true
	// });

// 	var turn = function(direction){
// 		console.log(direction)
// 	};

// 	var magazine = $('#flipbook');
// $("#flipbook").turn({
//     width: 750,
//     height: 667,
//     // autoCenter: true
// });


// 	$(document).on('keydown', function(e){
// 		switch (e.keyCode) {
// 			case 37: {
// 				turn('previous');
// 				break;
// 			};
// 			case 39: {
// 				turn('next');
// 				break;
// 			}
// 		}
// 	});